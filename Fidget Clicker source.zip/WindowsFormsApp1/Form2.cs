﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : MetroFramework.Forms.MetroForm
    {
        public Form2()
        {
            InitializeComponent();
        }

        int a = 0;

        

        decimal i = (decimal) 0;
        protected override void OnClosing(CancelEventArgs e)
        {
            Application.Exit();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            a++;
            metroLabel1.Text = a.ToString() + "번" ;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            i += (decimal) 0.1 ;
            metroLabel2.Text = i.ToString() + "초" ;
        }

        private void metroLabel2_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel3_Click(object sender, EventArgs e)
        {

        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("기록:" + i.ToString() + "초" + a.ToString() + "번");
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Hide();
        }

   
    }
}
