

NOTE:

To make use of designers, you must reference both MetroFramework.dll and MetroFramework.Design.dll 
from your project. I recommend to change the properties for the Design dll to "Copy local: false" 
as you do not need to redistribute it. This also helps to make your application independent of 
System.Design.dll and compatible with the .NET client profile, a subset of the full .NET framework.

Project Site: http://thielj.github.io/MetroFramework
